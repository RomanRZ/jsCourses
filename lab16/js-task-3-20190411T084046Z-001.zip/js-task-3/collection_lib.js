function Collection() {
   
};


function Queue() {
    
};


function FixedArray(size) {
    
};


function Set() {

};